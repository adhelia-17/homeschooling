<?php

namespace App\Filament\Resources\PendaftarOnlineResource\Pages;

use App\Filament\Resources\PendaftarOnlineResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendaftarOnline extends CreateRecord
{
    protected static string $resource = PendaftarOnlineResource::class;
}
