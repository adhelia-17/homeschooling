<?php

namespace App\Filament\Resources\PendaftarTrialResource\Pages;

use App\Filament\Resources\PendaftarTrialResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendaftarTrial extends CreateRecord
{
    protected static string $resource = PendaftarTrialResource::class;
}
